window.SITE_CONFIG = {
  siteName: "POS Solutions",
  whatsappNumber: "6281234567890", // ganti ke nomor Anda, format internasional tanpa + (contoh: 62812...)
  whatsappMessage: "Halo, saya tertarik dengan produk Anda",
  currency: "Rp"
};